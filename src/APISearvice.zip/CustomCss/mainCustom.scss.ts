/* tslint:disable */
require("./mainCustom.css");
const styles = {

};

export default styles;
/* tslint:enable */