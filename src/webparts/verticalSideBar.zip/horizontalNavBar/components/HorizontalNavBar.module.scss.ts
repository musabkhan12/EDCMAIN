/* tslint:disable */
require("./HorizontalNavBar.module.css");
const styles = {
  horizontalNavBar: 'horizontalNavBar_dc0f9421',
  teams: 'teams_dc0f9421',
  welcome: 'welcome_dc0f9421',
  welcomeImage: 'welcomeImage_dc0f9421',
  links: 'links_dc0f9421'
};

export default styles;
/* tslint:enable */