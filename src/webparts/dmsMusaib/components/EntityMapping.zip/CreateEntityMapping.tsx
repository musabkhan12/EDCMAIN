import * as React from 'react';
import Provider from '../../../GlobalContext/provider';
import styles from './BasicForm.module.scss';
import classNames from 'classnames';
import { getSP } from '../loc/pnpjsConfig';
import { SPFI } from '@pnp/sp';
import { useState, useEffect,useRef } from 'react';

function CreateEntityMapping() {
    const sp: SPFI = getSP();

    // State to manage fetched data
    const [departmentList, setDepartmentList] = useState<string[]>([]);
    const [divisionList, setDivisionList] = useState<string[]>([]);
    const [masterList, setMasterList] = useState<string[]>([]);

    // State to manage dropdown visibility
    const [showDepartmentDropdown, setShowDepartmentDropdown] = useState(false);
    const [showDivisionDropdown, setShowDivisionDropdown] = useState(false);
    const [showTitleDropdown, setShowTitleDropdown] = useState(false);

    // State to manage selected values
    const [selectedDepartment, setSelectedDepartment] = useState('');
    const [selectedDivision, setSelectedDivision] = useState('');
    const [selectedTitle, setSelectedTitle] = useState('');

    const departmentRef = useRef<HTMLDivElement | null>(null);
    const divisionRef = useRef<HTMLDivElement | null>(null);
    const titleRef = useRef<HTMLDivElement | null>(null);
    

    // Handle form submission
    const handleSubmit = async (event: any) => {
        event.preventDefault();
        const form = document.getElementById('createMaster') as HTMLFormElement;

        try {
            // Entity Lookup
            const entity = await sp.web.lists
                .getByTitle('MasterSiteURL')
                .items.filter(`Title eq '${selectedTitle}'`)
                .select('ID')()
                .then((items) => items[0]);

            if (!entity) throw new Error(`Entity with title "${selectedTitle}" not found.`);

            // Division Lookup
            const division = await sp.web.lists
                .getByTitle('DivisionMasterList')
                .items.filter(`Title eq '${selectedDivision}'`)
                .select('ID')()
                .then((items) => items[0]);

            if (!division) throw new Error(`Division with title "${selectedDivision}" not found.`);

            // Department Lookup
            const department = await sp.web.lists
                .getByTitle('DepartmentsMasterList')
                .items.filter(`Title eq '${selectedDepartment}'`)
                .select('ID')()
                .then((items) => items[0]);

            if (!department) throw new Error(`Department with title "${selectedDepartment}" not found.`);

            // Adding data to the EntityDivisionDepartmentMappingMasterList
            const newItem = await sp.web.lists.getByTitle('EntityDivisionDepartmentMappingMasterList').items.add({
                
                EntitylookupId: entity.ID, 
                Entitylookup_x003a_Title: `${selectedTitle}`,
                
                DevisionlookupId: division.ID, 
                Devisionlookup_x003a_Devision:`${selectedDepartment}`,

                DepartmentlookupId: department.ID,
                Departmentlookup_x003a_Departmen:`${selectedDepartment}`

            });

            console.log('Item added successfully:', newItem);
        } catch (error) {
            console.log('Error', error);
        }

        if (form) {
            form.submit();
        }
    };

    // Fetch data for dropdowns
    useEffect(() => {
        const getData = async () => {
            try {
                const departmentData = await sp.web.lists.getByTitle('DepartmentMasterList').items.select('Title')();
                const divisionData = await sp.web.lists.getByTitle('DivisionMasterList').items.select('Title')();
                const masterData = await sp.web.lists.getByTitle('MasterSiteURL').items.select('Title')();

                setDepartmentList(departmentData.map((item) => item.Title));
                setDivisionList(divisionData.map((item) => item.Title));
                setMasterList(masterData.map((item) => item.Title));
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        getData();
    }, []);

    // Function to handle selecting a dropdown option
    const handleSelect = (
        setSelectedValue: React.Dispatch<React.SetStateAction<string>>,
        value: string,
        setShowDropdown: React.Dispatch<React.SetStateAction<boolean>>,
        setShowOtherDropdowns: () => void
    ) => {
        setSelectedValue(value);
        setShowDropdown(false);
        setShowOtherDropdowns();
    };

    // used to hide the dropdown when click anywhere in the body
    const handleClickOutside = (event: MouseEvent) => {
        if (titleRef.current && !titleRef.current.contains(event.target as Node)) {
            setShowTitleDropdown(false);
        }
        if (divisionRef.current && !divisionRef.current.contains(event.target as Node)) {
            setShowDivisionDropdown(false);
        }
        if (departmentRef.current && !departmentRef.current.contains(event.target as Node)) {
            setShowDepartmentDropdown(false);
        }
    };

    useEffect(() => {
        document.addEventListener('mousedown', handleClickOutside);
        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
        };
    }, []);


    return (
        <>
            <div className={styles.DmsAdminForm}>
                <div className={styles.formcontainer}>
                    <div className={styles.apphier}>
                        <h1 className={styles.apptitle}>Basic Details</h1>
                    </div>
                    <hr className={styles.hrtag}></hr>
                    <form id="createMaster" onSubmit={handleSubmit}>
                        <div className={classNames(styles.formgroup, styles.topformgroup)}>
                            {/* Title Input */}
                            <div className={classNames(styles.halfrightform, styles.form1)}>
                                <label className={styles.label} htmlFor="Title">
                                    Title
                                </label>
                                <input
                                    className={styles.inputform1}
                                    id="Title"
                                    name="Title"
                                    value={selectedTitle}
                                    onChange={(e) => setSelectedTitle(e.target.value)}
                                    onFocus={() => {
                                        setShowTitleDropdown(true);
                                        setShowDivisionDropdown(false);
                                        setShowDepartmentDropdown(false);
                                    }}
                                
                                />
                                {showTitleDropdown && (
                                    <div className={styles.dropdown}>
                                        {masterList
                                            .filter((item) =>
                                                item.toLowerCase().includes(selectedTitle.toLowerCase())
                                            )
                                            .map((item, index) => (
                                                <div
                                                    key={index}
                                                    className={styles.dropdownItem}
                                                    onClick={() => handleSelect(setSelectedTitle, item, setShowTitleDropdown, () => {
                                                        setShowTitleDropdown(false);
                                                        setShowDivisionDropdown(false);
                                                        setShowDepartmentDropdown(false);
                                                    })}
                                                >
                                                    {item}
                                                </div>
                                            ))}
                                    </div>
                                )}
                            </div>

                            {/* Division Input (Disabled until Title is selected) */}
                            <div className={classNames(styles.halfrightform, styles.form1)}>
                                <label className={styles.label} htmlFor="Division">
                                    Division
                                </label>
                                <input
                                    className={styles.inputform1}
                                    id="Division"
                                    name="Division"
                                    value={selectedDivision}
                                    onChange={(e) => setSelectedDivision(e.target.value)}
                                    onFocus={() => {
                                        setShowTitleDropdown(false);
                                        setShowDivisionDropdown(true);
                                        setShowDepartmentDropdown(false);
                                    }}
                                    disabled={!selectedTitle} // Disable if no Title is selected
                                />
                                {showDivisionDropdown && selectedTitle && (
                                    <div className={styles.dropdown}>
                                        {divisionList
                                            .filter((item) =>
                                                item.toLowerCase().includes(selectedDivision.toLowerCase())
                                            )
                                            .map((item, index) => (
                                                <div
                                                    key={index}
                                                    className={styles.dropdownItem}
                                                    onClick={() => handleSelect(setSelectedDivision, item, setShowDivisionDropdown, () => {
                                                        setShowTitleDropdown(false);
                                                        setShowDivisionDropdown(false);
                                                        setShowDepartmentDropdown(false);
                                                    })}
                                                >
                                                    {item}
                                                </div>
                                            ))}
                                    </div>
                                )}
                            </div>

                            {/* Department Input (Disabled until Division is selected) */}
                            <div className={classNames(styles.halfrightform, styles.form1)}>
                                <label className={styles.label} htmlFor="Department">
                                    Department
                                </label>
                                <input
                                    className={styles.inputform1}
                                    id="Department"
                                    name="Department"
                                    value={selectedDepartment}
                                    onChange={(e) => setSelectedDepartment(e.target.value)}
                                    onFocus={() => {
                                        setShowTitleDropdown(false);
                                        setShowDivisionDropdown(false);
                                        setShowDepartmentDropdown(true);
                                    }}
                                    disabled={!selectedDivision || !selectedTitle} // Disable if no Division and Title is selected is selected
                                />
                                {showDepartmentDropdown && selectedDivision && (
                                    <div className={styles.dropdown}>
                                        {departmentList
                                            .filter((item) =>
                                                item.toLowerCase().includes(selectedDepartment.toLowerCase())
                                            )
                                            .map((item, index) => (
                                                <div
                                                    key={index}
                                                    className={styles.dropdownItem}
                                                    onClick={() => handleSelect(setSelectedDepartment, item, setShowDepartmentDropdown, () => {
                                                        setShowTitleDropdown(false);
                                                        setShowDivisionDropdown(false);
                                                        setShowDepartmentDropdown(false);
                                                     })}
                                                >
                                                    {item}
                                                </div>
                                            ))}
                                    </div>
                                )}
                            </div>
                        </div>
                    </form>
                </div>
                <div className={styles.approvecancel}>
                    <button
                        type="submit"
                        className={styles.backbuttonform1}
                        onClick={handleSubmit}
                        // disabled={!selectedTitle || !selectedDivision || !selectedDepartment} // Disable submit if any field is missing
                    >
                        <p className={styles.Addtext}>Create</p>
                    </button>
                    <button type="button" className={styles.addbuttonargform1}>
                        <p className={styles.Addtext}>Cancel</p>
                    </button>
                </div>
            </div>
        </>
    );
}


export default CreateEntityMapping;
