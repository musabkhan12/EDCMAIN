/* tslint:disable */
require("./BasicForm.module 1.css");
const styles = {

};

export default styles;
/* tslint:enable */