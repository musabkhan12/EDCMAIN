declare global {
    interface Window {
      managePermission:(message:string) => void;
      manageWorkflow:(message:string) => void;
      view:(message:string) => void;
      PreviewFile: (path: string, siteID: string, docLibName:any) => void;
      deleteFile:(fileId: string , siteID:string, listToUpdate:any ) => void;
    }
  }
  interface UploadFileProps {
    currentfolderpath: {
      CurrentEntity: string;
      currentEntityURL: string;
      currentsiteID: string;
      // ... other properties
    };
  }

  // @ts-ignore
  import * as React from "react";
  import { getSP } from "../loc/pnpjsConfig";
  import { SPFI } from "@pnp/sp";
  import "bootstrap/dist/css/bootstrap.min.css";
  // import "bootstrap//dist/"
  import "../../../CustomCss/mainCustom.scss";
  import "../../verticalSideBar/components/VerticalSidebar.scss";
  import VerticalSideBar from "../../verticalSideBar/components/VerticalSideBar";
  import UserContext from "../../../GlobalContext/context";
  // import { useState , useEffect } from "react";
  import Provider from "../../../GlobalContext/provider";
  import { useMediaQuery } from "react-responsive";
  import "@pnp/sp/webs";
  import "@pnp/sp/folders";
  import "@pnp/sp/files";
  import "@pnp/sp/sites"
  import "@pnp/sp/presets/all"
  import { PermissionKind } from "@pnp/sp/security";
  import "bootstrap/dist/css/bootstrap.min.css";
  import "../../../CustomCss/mainCustom.scss";
  import "../../verticalSideBar/components/VerticalSidebar.scss";
  import "./dmscss";
  import "./DMSAdmincss"
  import { useState , useRef , useEffect} from "react";
  import {IDmsMusaibProps} from './IDmsMusaibProps'
  import HorizontalNavbar from "../../horizontalNavBar/components/HorizontalNavBar";
   import EntityMapping from "./EntityMapping";
import Devision from "./Division";
import Department from "./Department";
import CreateEntity from "./CreateEntity";
    
  
  
  const Dmsadmin = ({ props }: any) => {
    const sp: SPFI = getSP();

    const { useHide }: any = React.useContext(UserContext);
    const elementRef = React.useRef<HTMLDivElement>(null);

    
  
    React.useEffect(() => {
      // console.log("This function is called only once", useHide);
  
      const showNavbar = (
        toggleId: string,
        navId: string,
        bodyId: string,
        headerId: string
      ) => {
        const toggle = document.getElementById(toggleId);
        const nav = document.getElementById(navId);
        const bodypd = document.getElementById(bodyId);
        const headerpd = document.getElementById(headerId);
  
        if (toggle && nav && bodypd && headerpd) {
          toggle.addEventListener("click", () => {
            nav.classList.toggle("show");
            toggle.classList.toggle("bx-x");
            bodypd.classList.toggle("body-pd");
            headerpd.classList.toggle("body-pd");
          });
        }
      };
  
      showNavbar("header-toggle", "nav-bar", "body-pd", "header");
  
      const linkColor = document.querySelectorAll(".nav_link");
  
      function colorLink(this: HTMLElement) {
        if (linkColor) {
          linkColor.forEach((l) => l.classList.remove("active"));
          this.classList.add("active");
        }
      }
  
      linkColor.forEach((l) => l.addEventListener("click", colorLink));
    }, [useHide]);
    // Media query to check if the screen width is less than 768px
    const isMobile = useMediaQuery({ query: "(max-width: 768px)" });
  
    React.useEffect(() => {
      // console.log("This function is called only once", useHide);
  
      const showNavbar = (
        toggleId: string,
        navId: string,
        bodyId: string,
        headerId: string
      ) => {
        const toggle = document.getElementById(toggleId);
        const nav = document.getElementById(navId);
        const bodypd = document.getElementById(bodyId);
        const headerpd = document.getElementById(headerId);
  
        if (toggle && nav && bodypd && headerpd) {
          toggle.addEventListener("click", () => {
            nav.classList.toggle("show");
            toggle.classList.toggle("bx-x");
            bodypd.classList.toggle("body-pd");
            headerpd.classList.toggle("body-pd");
          });
        }
      };
  
      showNavbar("header-toggle", "nav-bar", "body-pd", "header");
  
      const linkColor = document.querySelectorAll(".nav_link");
  
      function colorLink(this: HTMLElement) {
        if (linkColor) {
          linkColor.forEach((l) => l.classList.remove("active"));
          this.classList.add("active");
        }
      }
  
      linkColor.forEach((l) => l.addEventListener("click", colorLink));
    }, [useHide]);
    React.useEffect(() => {
      const handleEscape = (e: KeyboardEvent) => {
        if (e.key === "Escape") {
          if (document.fullscreenElement) {
            document.exitFullscreen();
          }
        }
      };
  
      window.addEventListener("keydown", handleEscape);
      return () => window.removeEventListener("keydown", handleEscape);
    }, []);

    const [Mylistdata, setMylistdata] = useState([]);
  ////
  const [activeComponent, setActiveComponent] = useState<string >('');
  ////
 console.log(activeComponent , "activeComponent")
  const handleReturnToMain = (Name:any) => {
    setActiveComponent(Name); // Reset to show the main component
    console.log(activeComponent , "activeComponent updated")
  };
    const getmasterlis = async () => {
      try {
        const items = await sp.web.lists.getByTitle('DMSAdmin').items();
        console.log(items, "getmasterlis");
        setMylistdata(items);
        
      } catch (error) {
        console.error("Error fetching list items:", error);
      }
    };
    console.log(Mylistdata , "Mylistdata")
    useEffect(() => {
      getmasterlis();
    }, []);
    return (
      <div id="wrapper" ref={elementRef}>
      <div
        className="app-menu"
        id="myHeader">
        <VerticalSideBar _context={sp} />
      </div>
      <div className="content-page">
        <HorizontalNavbar/>
        <div className="content" style={{marginLeft: `${!useHide ? '240px' : '80px'}`,marginTop:'1.5rem'}}>
         
        <div className="container-fluid  paddb">
        {activeComponent === "" ?
                 (<div>
                      <div className="DMSMasterContainer">
                  <h4 className="page-title fw-bold mb-1 font-20">Settings</h4>
                  <div className="Route">
                    {" "}
                    <h2 className="Home">Home</h2>
                    <span className="greater">&gt;</span>{" "}
                    <h2 className="Setting">Settings</h2>{" "}
                  </div>
                  <div className="row manage-master mt-3">
                    {Mylistdata.map((item: any) => {
                      const imageData = JSON.parse(item.Image); // Assuming 'ImageColumn' is the column name
                      const itemid = String(item.Id);
                      console.log(itemid, "itemsid");
                      console.log(imageData, "imagedata");
                      const imageUrl = `https://officeindia.sharepoint.com//_api/v2.1/sites('338f2337-8cbb-4cd1-bed1-593e9336cd0e,e2837b3f-b207-41eb-940b-71c74da3d214')/lists('3f31e4eb-27b3-4370-b5cd-8cf594981912')/items('${itemid}')/attachments('${imageData.fileName}')/thumbnails/0/c3000x2000/content?prefer=noredirect,closestavailablesize`;
                      console.log(imageUrl, "imageurl");
                      return (
                        <div className="col-sm-3 col-md-3 mt-2">
                          <a href={item?.LinkUrl}>
                            <div className="card-master box1" onClick={()=>handleReturnToMain(item.Name)}>
                              <div className="icon">
                                <img className="CardImage" src={imageUrl} />
                              </div>
                              <p className="text-dark">{item.Name}</p>
                            </div>
                          </a>
                        </div>
                      );
                    })}
                  </div>
                </div>
                 </div>) : (
                  <div>
                    {activeComponent === 'Create Entity' && (
                      <div>
     <button onClick={()=>handleReturnToMain('')}> Back </button>
     <CreateEntity/>
                      </div>
                 
                    )} 
                    {activeComponent === 'Create Devision' && (
                      <div>
          <button onClick={()=>handleReturnToMain('')}> Back </button>
          <Devision/>
                      </div>
            
                    )} 
                    {activeComponent === 'Create Department' && (
                      <div>
 <button onClick={()=>handleReturnToMain('')}> Back </button>
 <Department/>
                      </div>
                     
                    )} 
                    {activeComponent === 'Map Devision & Department' && (
                      <div>
          <button onClick={()=>handleReturnToMain('')}> Back</button>
          <EntityMapping/>
                      </div>
            
                    )} 
                  </div>
                 
              
                 )
                 }
                </div>
              </div>
            </div>
            </div>
     
          
    );
  };
  
  
  
  const DMSAdmin: React.FC<IDmsMusaibProps> = (props) =>{
    return (
      <Provider>
        <Dmsadmin  props={props}/>
      </Provider>
    );
  };
  
  export default DMSAdmin;
  