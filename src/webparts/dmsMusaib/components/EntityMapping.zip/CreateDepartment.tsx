import * as React from 'react';
import Provider from '../../../GlobalContext/provider';
import  styles from './BasicForm.module.scss'
import classNames from "classnames";
import { getSP } from '../loc/pnpjsConfig';
import { SPFI } from '@pnp/sp';
import { useState} from "react";
// import {BasicFormProps} from '../components/IBasicFormProps1'

interface BasicFormProps {
    currentId :any,
    currentJobTitle:any,
    currentIsActive:any,
    onCancel:any,
}

const CreateDepartment: React.FC<BasicFormProps> = ({
    currentId,
    currentJobTitle,
    currentIsActive,
    onCancel,
})=>{

    const sp: SPFI = getSP();
    // console.log(sp);

    const dynamicHeading =currentId ? "Edit Department" : "Create Department";

    const [jobTitle, setJobTitle] = useState(currentJobTitle || '');
    const [isActive, setIsActive] = useState(currentIsActive || '');
    console.log("Oncancle",onCancel);

    const handleSubmit = async (event: any) => {
        event.preventDefault(); 

        // console.log(jobTitle,isActive)
        const form=document.getElementById('createDepartment') as HTMLFormElement

        const newItem = {
            Title: jobTitle, 
            Active: isActive, 
        };
        console.log(newItem);

        const listTitle='DepartmentMasterList';

        try {

            if (currentId) {
                // Update existing Department
                await sp.web.lists.getByTitle(listTitle).items.getById(currentId).update(newItem);
                alert('Department updated successfully');

            } else {                
                // Create new Department
                await sp.web.lists.getByTitle(listTitle).items.add(newItem);
                alert('Department added successfully');
            }

        } catch (error) {
            console.error('Error adding item:', error);
            alert('Error adding item');
        }

        if(form){
            form.submit();
        }
    };

  return (
        
    <>  
        <div className={styles.DmsAdminForm}>
        <div className={styles.formcontainer}>            
            <div className={styles.apphier}>
                <h1 className={styles.apptitle}>Basic Details</h1>
            </div>
            <hr className={styles.hrtag}></hr>
            <form id="createDepartment" onSubmit={handleSubmit}>
                <div className={classNames(styles.formgroup, styles.topformgroup)}>
                    <div className={classNames(styles.halfrightform, styles.form1)}>
                        <label className={styles.label} htmlFor="jobTitle">
                            {dynamicHeading}
                        </label>
                        <input
                            className={styles.inputform1}
                            id="jobTitle"
                            name="jobTitle"
                            value={jobTitle}
                            onChange={(e) => setJobTitle(e.target.value)}
                        />
                    </div>
                    <div className={classNames(styles.halfrightform, styles.form1)}>
                        <label className={styles.label} htmlFor="isActive">
                            isActive
                        </label>
                        <div className={styles.radioContainer}>
                        <div className={styles.radioContainer}>
                            <div className={styles.radioItem}>
                            <input
                                type="radio"
                                id="yesOption"
                                name="isActive"
                                value="Yes"
                                checked={isActive === 'Yes'}
                                onChange={(e) => setIsActive(e.target.value)}
                            />
                            <label htmlFor="yesOption">Yes</label>
                            </div>
                            <div className={styles.radioItem}>
                            <input
                                type="radio"
                                id="noOption"
                                name="isActive"
                                value="No"
                                checked={isActive === 'No'}
                                onChange={(e) => setIsActive(e.target.value)}
                            />
                            <label htmlFor="noOption">No</label>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
                </form>
        </div>
        
        <div className={styles.approvecancel}>
                    <button type="submit" className={styles.backbuttonform1} onClick={handleSubmit}>
                        <p className={styles.Addtext}>Submit</p>
                    </button>
                    <button type="button" className={styles.addbuttonargform1}>
                        <p className={styles.Addtext}>Cancel</p>
                    </button>
        </div>
    </div>
    </>
  )
}

const CreateDepartment2: React.FC<BasicFormProps> = ({
    currentId,
    currentJobTitle,
    currentIsActive,
    onCancel,
})=> {
    return (
        <Provider>
            <CreateDepartment
                    currentId={currentId}
                    currentJobTitle={currentJobTitle}
                    currentIsActive={currentIsActive}
                    onCancel={onCancel} 
            />
        </Provider>
    );
};

export default CreateDepartment2;
